import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contact-page-section',
  templateUrl: './contact-page-section.component.html',
  styleUrls: ['./contact-page-section.component.css']
})
export class ContactPageSectionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
