import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-newsletter-box',
  templateUrl: './newsletter-box.component.html',
  styleUrls: ['./newsletter-box.component.css']
})
export class NewsletterBoxComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
