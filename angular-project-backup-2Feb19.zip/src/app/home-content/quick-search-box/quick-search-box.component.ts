import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quick-search-box',
  templateUrl: './quick-search-box.component.html',
  styleUrls: ['./quick-search-box.component.css']
})
export class QuickSearchBoxComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
