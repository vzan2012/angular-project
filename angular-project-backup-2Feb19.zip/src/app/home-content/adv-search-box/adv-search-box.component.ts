import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adv-search-box',
  templateUrl: './adv-search-box.component.html',
  styleUrls: ['./adv-search-box.component.css']
})
export class AdvSearchBoxComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
